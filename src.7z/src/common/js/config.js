export const playMode = {
    sequence: 0,  //顺序播放
    loop: 1,      //循环播放  
    random : 2    //随机播放
}